
class Office:
    # fill in your own code
    
    def add_package_to_mailout(self, package):
        ''' 
            >>> pack1 = Package(1,101,102)
            >>> office101 = Office(101)
            >>> office101.add_package_to_mailout(pack1)
            >>> print(office101)
                Office id: 101
                Mail-in Packages: 
                Mail-out Packages: 
                packet id: 1, from: 101, to: 102, current: 101, status: to mail
            
        '''
        # fill in your own code
        pass

    def add_package_to_mailin(self, package):
        ''' 
            >>> pack1 = Package(1,101,102)
            >>> office102 = Office(102)
            >>> office102.add_package_to_mailin(pack1)
            >>> print(office102)
                Office id: 102
                Mail-in Packages: 
                packet id: 1, from: 101, to: 102, current: 101, status: to mail
                Mail-out Packages:

        '''
        # fill in your own code
        pass
    
    def transfer(self,dest_office):
        ''' 
            >>> pack1 = Package(1,101,102)
            >>> office101 = Office(101)
            >>> office102 = Office(102)
            >>> office101.add_package_to_mailout(pack1)
            >>> office101.transfer(office102)
            >>> print(office101)
                Office id: 101
                Mail-in Packages: 
                Mail-out Packages: 
                packet id: 1, from: 101, to: 102, current: 101, status: on the way

        '''
        # fill in your own code
        pass

    def deliver(self, dest_office):
        ''' 
            >>> pack1 = Package(1,101,102)
            >>> office101 = Office(101)
            >>> office102 = Office(102)
            >>> office101.add_package_to_mailout(pack1)
            >>> office101.transfer(office102)
            >>> office101.deliver(office102)
            >>> print(office102)
                Office id: 102
                Mail-in Packages: 
                packet id: 1, from: 101, to: 102, current: 102, status: delivered
                Mail-out Packages: 

            >>> print(office101)
                Office id: 101
                Mail-in Packages: 
                Mail-out Packages:
                
        '''        
        # fill in your own code
        pass

    def clear(self):
        # fill in your own code
        pass

    ### for level 3
    def deliver2(self, dest_office):
        ''' 
            >>> pack1 = Package(1,101,102)
            >>> office101 = Office(101)
            >>> office102 = Office(102)
            >>> office101.add_package_to_mailout(pack1)
            >>> office101.transfer(office102)
            >>> office101.deliver(office102)
            >>> print(office102)
                Office id: 102
                Mail-in Packages: 
                packet id: 1, from: 101, to: 102, current: 102, status: delivered
                Mail-out Packages: 

            >>> print(office101)
                Office id: 101
                Mail-in Packages: 
                Mail-out Packages:
                
        '''
        # fill in your own code
        pass
    

    
